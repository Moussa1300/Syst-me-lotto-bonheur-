LOTO BONHEUR ANALYSE CI — PROJET ANDROID
========================================

Ce dossier est un projet source Android Studio (wrapper WebView) intégrant la version web de l'application dans les ressources locales.

FONCTIONS
- Saisie et import de tirages
- Fréquences gagnants et machine séparées
- Matrice expérimentale de 10 BK et paires inversées
- Historique local et export CSV
- Les données saisies sont conservées dans le stockage local de l'application

OUVRIR ET CONSTRUIRE
1. Installer Android Studio sur un ordinateur.
2. Décompresser LotoBonheurAndroid.zip.
3. Dans Android Studio, choisir Open et sélectionner le dossier LotoBonheurAndroid.
4. Autoriser Android Studio à installer les composants SDK demandés et attendre la synchronisation Gradle.
5. Pour tester : connecter le téléphone en USB (débogage USB activé) et cliquer Run.
6. Pour un APK de test : Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Pour Google Play : produire un Android App Bundle (.aab) signé depuis Build > Generate Signed Bundle / APK.

LIMITES ACTUELLES
- Ce dossier contient le code source Android, pas un APK précompilé.
- Le SDK Android/Gradle n'était pas disponible dans l'environnement de génération, donc la compilation et le test sur appareil restent à faire dans Android Studio.
- Aucune récupération automatique des résultats LONACI n'est intégrée. Importez ou saisissez uniquement des résultats vérifiés.
- La matrice classe des fréquences historiques; elle ne prédit ni ne garantit un résultat gagnant.
- Avant publication, vérifier les exigences Google Play en vigueur, la politique de confidentialité, la fiche Play Store, les captures d'écran, l'icône et la signature de production.
