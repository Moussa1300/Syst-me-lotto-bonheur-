LOTO BONHEUR ANALYSE CI — VERSION 2

CONTENU
- index.html : application web en un fichier principal
- manifest.webmanifest, sw.js, icon.svg : support pour une installation PWA lorsqu'elle est hébergée en HTTPS
- modele_loto_bonheur_ci.csv : modèle à télécharger dans l'application

UTILISATION RAPIDE SUR ANDROID
1. Transférez le fichier index.html sur votre téléphone ou ouvrez-le depuis les téléchargements.
2. Ouvrez-le avec Chrome ou un navigateur compatible.
3. Ajoutez les dates, catégories, numéros gagnants et numéros machine.
4. Les fréquences, numéros chauds/froids, BK inversés et matrice se recalculent à partir des données saisies.
5. Exportez régulièrement votre historique en CSV ou JSON.

INSTALLATION COMME APPLICATION ANDROID (PWA)
Pour que Chrome propose « Installer l'application » ou « Ajouter à l'écran d'accueil » avec mode hors ligne, hébergez le contenu du dossier sur un site HTTPS statique. Ouvrir directement index.html depuis les fichiers permet d'utiliser le prototype, mais le service worker et l'installation PWA dépendent du navigateur et du mode d'ouverture.

FORMAT CSV
date;categorie;gagnants;machine
2026-10-28;Matinale;02 17 26 62 72;03 18 27 48 84
Une ligne par tirage. La ligne d'exemple est fictive et sert uniquement à montrer le format, pas un résultat officiel.

LIMITES
- Aucune connexion automatique au site LONACI.
- Les résultats officiels doivent être vérifiés et saisis/importés par l'utilisateur.
- La matrice est un classement heuristique de fréquences passées, non une prédiction fiable de résultats futurs.
- Les données sont gardées dans le stockage local du navigateur; exporter une sauvegarde avant d'effacer les données du navigateur.
